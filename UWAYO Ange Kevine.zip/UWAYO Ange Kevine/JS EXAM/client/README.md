Getting Started with Your React App
This project was initialized using Create React App.

Scripts You Can Use
In the project directory, you can run the following commands:

npm start
Starts the development server.
Open http://localhost:3000 to view the app in your browser.

The page will automatically reload if you make edits.
You will also see any lint errors in the console.

npm test
Launches the test runner in interactive watch mode.
Refer to the running tests section for more details.

npm run build
Creates a production-ready build in the build folder.
It optimizes the build for the best performance, bundling React in production mode and minifying the files.

The build is minified, and filenames include hashes.
Your app is ready for deployment!

Check the deployment section for more information.

npm run eject
Warning: this is a one-way operation. Once you eject, you cannot go back!

If you are not satisfied with the default build tool and configuration, you can eject at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc.) directly into your project, giving you full control over them. All the commands except eject will continue to work, but they will point to the copied scripts, which you can then modify.

Ejecting is not mandatory. The default feature set is suitable for small to medium deployments, and you should not feel compelled to use this feature. However, it is available if you need more customization.

Further Reading
For more information, refer to the Create React App documentation.

To learn more about React, visit the React documentation.

Code Splitting
Details about code splitting have been moved to this page.

Analyzing the Bundle Size
Instructions on analyzing bundle size have been relocated here.

Making a Progressive Web App
Guidance on creating a Progressive Web App can be found here.

Advanced Configuration
Advanced configuration options are available here.

Deployment
Deployment instructions have been moved to this page.

npm run build fails to minify
Troubleshooting for build minification issues is now located here.
<h1> UWAYO Ange Kevine </h1>